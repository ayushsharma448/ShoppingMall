package com.example5.demo5.repository;


import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.example5.demo5.Entity.Seller;

@Repository
public interface SellerRepo extends PagingAndSortingRepository<Seller, Long>
{

	@Query("SELECT e FROM Seller e WHERE e.sellerId > :sid") //Named parameter
	List<Seller> findAbc(@Param("sid") Long sellerId);
	
		
	  @Transactional
	  
	  @Query(value="Update Seller s SET s.s_quantity = s.s_quantity + :sQuant where s.pid=:id", nativeQuery=true)	  
	  @Modifying void updateQantityToSeller(@Param("sQuant") Long sQuant,@Param("id") Long id);
	  
/**
 * @param sQuant
 * @param id
 */

	  
}
