package com.example5.demo5.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Seller")
public class Seller {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="sid")
	private long id;
	
	@Column(name="pid")
	private long pid;
	
	@Column(name="sQuantity")
	private long sQuantity;
	
	public Seller() 
	{
		super();
	}


	@Override
	public String toString() {
		return "Seller [id=" + id + ", pid=" + pid + ", sQuantity=" + sQuantity + "]";
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public long getPid() {
		return pid;
	}

	public void setPid(long pid) {
		this.pid = pid;
	}

	public long getsQuantity() {
		return sQuantity;
	}

	public void setsQuantity(long sQuantity) {
		this.sQuantity = sQuantity;
	}

	
}
