package com.example5.demo5.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example5.demo5.Entity.Product;
import com.example5.demo5.Entity.User;
import com.example5.demo5.repository.ProductRepo;
import com.example5.demo5.service.ProductService;
import com.example5.demo5.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ShoppingController {

	@Autowired
	ProductService prodService;	
	
	@Autowired
	UserService userService;
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addProduct")
	Product addProduct(@Valid @RequestBody Product addProd)
	{		
		return prodService.addProduct(addProd);
	}
	
	@PostMapping("/createUser")
	User createUser(@Valid @RequestBody User userDtls)
	{		
		return userService.createUser(userDtls);
	}
	
	@GetMapping("/getProduct")
	List<Product> geProductDtls()
	{
		return prodService.getProductDtls();
	}
	
	@GetMapping(value="/getnamecategory/{name}/{category}", headers="Accept=application/json")
	 public List<Product> getnamecategory(@PathVariable String name, @PathVariable String category) {	 
	  List<Product> tasks=prodService.findByNameAndCategory(name, category);
	  return tasks;	
	 }
}
