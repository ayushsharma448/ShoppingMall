package com.example5.demo5.service;
import java.util.List;

import com.example5.demo5.Entity.Product;
import com.example5.demo5.Entity.User;



public interface UserService 
{
	public User createUser(User user);

	
}
